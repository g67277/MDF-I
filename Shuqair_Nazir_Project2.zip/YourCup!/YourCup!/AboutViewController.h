//
//  AboutViewController.h
//  YourCup!
//
//  Created by Nazir Shuqair on 3/13/14.
//  Copyright (c) 2014 Me Time Studios. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DataLayerSchedule.h"

@interface AboutViewController : UIViewController{
    
    IBOutlet UILabel* appName;
    IBOutlet UITextView* appDisk;
}


@end
