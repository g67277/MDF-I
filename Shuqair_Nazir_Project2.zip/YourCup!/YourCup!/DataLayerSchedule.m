//
//  DataLayerSchedule.m
//  YourCup!
//
//  Created by Nazir Shuqair on 3/9/14.
//  Copyright (c) 2014 Me Time Studios. All rights reserved.
//

#import "DataLayerSchedule.h"

@implementation DataLayerSchedule
@synthesize cCity,cDate,cTeam1,cTeam1Image,cTeam1Points,cTeam2,cTeam2Image,cTeam2Points,cTime,cWeather, cStadiumImg, cCityImg;
@synthesize cLinkLabel, cResearchImg, cResearchLabel, cResearchText;
@synthesize cAppDisk, cAppName;



@end
