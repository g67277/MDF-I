//
//  YourCup_Tests.m
//  YourCup!Tests
//
//  Created by Nazir Shuqair on 3/8/14.
//  Copyright (c) 2014 Me Time Studios. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface YourCup_Tests : XCTestCase

@end

@implementation YourCup_Tests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
