//
//  DataLayer.m
//  MDF1-WK1-YourCup
//
//  Created by Nazir Shuqair on 3/5/14.
//  Copyright (c) 2014 Me Time Studios. All rights reserved.
//

#import "DataLayer.h"

@implementation DataLayer
@synthesize cCity,cDate,cTeam1,cTeam1Image,cTeam1Points,cTeam2,cTeam2Image,cTeam2Points,cTime,cWeather, cStadiumImg;



@end
